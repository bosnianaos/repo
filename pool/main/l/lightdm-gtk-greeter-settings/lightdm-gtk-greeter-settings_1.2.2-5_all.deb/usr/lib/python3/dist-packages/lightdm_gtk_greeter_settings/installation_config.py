__all__ = ["__config_path__", "__data_directory__", "__version__"]
__config_path__ = "/etc/lightdm/lightdm-gtk-greeter.conf"
__data_directory__ = '/usr/share/lightdm-gtk-greeter-settings/'
__version__ = '1.2.2'
