'''auto-generated version from setuptools_scm'''
__version__ = "0.28.7"
