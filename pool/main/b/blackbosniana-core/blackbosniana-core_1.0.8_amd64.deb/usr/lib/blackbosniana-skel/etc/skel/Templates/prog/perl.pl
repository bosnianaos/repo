#!/usr/bin/perl

print("OpenBosniana OS Template");
