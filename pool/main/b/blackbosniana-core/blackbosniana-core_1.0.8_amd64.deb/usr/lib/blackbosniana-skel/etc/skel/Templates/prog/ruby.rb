#!/usr/bin/ruby

puts "OpenBosniana OS Template"
