class HelloWorld {
    static void Main() {
        System.Console.WriteLine("OpenBosniana OS Template");
    }
}
