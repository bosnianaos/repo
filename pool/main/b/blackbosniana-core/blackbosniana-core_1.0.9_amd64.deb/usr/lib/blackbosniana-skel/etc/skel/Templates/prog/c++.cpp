#include <iostream>

using namespace std;

main()
{
	cout << "OpenBosniana OS Template" << endl;
	return 0;
}
