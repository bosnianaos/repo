#include <stdio.h>

int main(int argc, char **argv)
{
	printf("OpenBosniana OS Template\n");
	return 0;
}
