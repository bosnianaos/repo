#!/usr/bin/perl6

say "OpenBosniana OS Template";
