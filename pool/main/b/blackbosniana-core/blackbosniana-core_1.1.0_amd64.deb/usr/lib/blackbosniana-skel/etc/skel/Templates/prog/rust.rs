fn main() {
    println!("OpenBosniana OS Template");
}
