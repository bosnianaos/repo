#!/bin/bash

echo "OpenBosniana OS Template"
